<?php

function index()
{
	render("book/index");	
}