<?php 
header("Location:" . URL . "book/") ?>
<!doctype html>

<html>
	<head>
		<title>Verjaardagskalender</title>
        <link href="public/css/style.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
    <h1>hoi</h1>
    <a href="<?= URL ?>book/">author</a>

	</body>
</html>
