<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Author Plaza</title>
	<link href="public/css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<main>